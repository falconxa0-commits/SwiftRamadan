import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/session';
import { captureException } from '@/lib/monitoring/sentry';

// Prize definitions with probabilities
const PRIZES = [
  { id: 1, type: 'discount', value: 500, label: '₦500 Off', probability: 0.20 },
  { id: 2, type: 'swiftPoints', value: 50, label: '50 SwiftPoints', probability: 0.20 },
  { id: 3, type: 'freeDelivery', value: 1, label: 'Free Delivery', probability: 0.10 },
  { id: 4, type: 'discount', value: 1000, label: '₦1,000 Off', probability: 0.10 },
  { id: 5, type: 'swiftPoints', value: 100, label: '100 SwiftPoints', probability: 0.10 },
  { id: 6, type: 'multiplier', value: 2, label: '2x Points Tomorrow', probability: 0.10 },
  { id: 7, type: 'discount', value: 2500, label: '₦2,500 Off', probability: 0.05, rare: true },
  { id: 8, type: 'jackpot', value: 500, label: '500pts + ₦500 Off', probability: 0.05, jackpot: true },
];

// Server-side spin state tracking — keyed by userId
const spinStateMap = new Map<string, { lastSpinDate: string; streak: number }>();

// In-memory rate limiting (per IP, resets on server restart)
const rateLimitMap = new Map<string, { count: number; resetAt: number }>();

function checkRateLimit(ip: string): boolean {
  const now = Date.now();
  const entry = rateLimitMap.get(ip);
  
  if (!entry || now > entry.resetAt) {
    rateLimitMap.set(ip, { count: 1, resetAt: now + 60_000 }); // 1 minute window
    return true;
  }
  
  if (entry.count >= 5) {
    return false; // Rate limited
  }
  
  entry.count++;
  return true;
}

// Cryptographic randomness — uses crypto.getRandomValues() instead of Math.random()
function spinWheel(): typeof PRIZES[number] {
  const array = new Uint32Array(1);
  crypto.getRandomValues(array);
  // Convert to a float in [0, 1) with 32 bits of precision
  const random = array[0] / 0x100000000;
  
  let cumulative = 0;
  
  for (const prize of PRIZES) {
    cumulative += prize.probability;
    if (random <= cumulative) {
      return prize;
    }
  }
  
  // Fallback to first prize (should rarely happen due to floating point)
  return PRIZES[0];
}

// GET: Returns spin status — server-side tracking, no client input trusted
export async function GET(request: NextRequest) {
  const auth = await requireAuth(request);
  if (auth instanceof NextResponse) return auth;

  const ip = request.headers.get('x-forwarded-for') || 'unknown';
  
  if (!checkRateLimit(ip)) {
    return NextResponse.json(
      { error: 'Rate limited. Please wait a moment.' },
      { status: 429 }
    );
  }
  
  const userId = auth.userId;
  const today = new Date().toISOString().split('T')[0];

  // Look up server-side spin state
  const state = spinStateMap.get(userId);
  const lastSpinDate = state?.lastSpinDate ?? '';
  const streak = state?.streak ?? 0;

  const canSpin = lastSpinDate !== today;
  const hasStreakBonus = streak >= 3;
  
  return NextResponse.json({
    canSpin,
    lastSpinDate,
    streak,
    hasStreakBonus,
    prizes: PRIZES.map(p => ({
      id: p.id,
      type: p.type,
      value: p.value,
      label: p.label,
      rare: p.rare || false,
      jackpot: p.jackpot || false,
    })),
  });
}

// POST: Perform a spin — server-side tracking prevents replay/cheating
export async function POST(request: NextRequest) {
  const auth = await requireAuth(request);
  if (auth instanceof NextResponse) return auth;

  const ip = request.headers.get('x-forwarded-for') || 'unknown';
  
  if (!checkRateLimit(ip)) {
    return NextResponse.json(
      { error: 'Rate limited. Please wait a moment.' },
      { status: 429 }
    );
  }
  
  try {
    const userId = auth.userId;
    const today = new Date().toISOString().split('T')[0];

    // Look up server-side spin state (ignore any client-provided data)
    const state = spinStateMap.get(userId);
    const lastSpinDate = state?.lastSpinDate ?? '';
    const currentStreak = state?.streak ?? 0;
    
    // Validate: can only spin once per day (server-side check)
    if (lastSpinDate === today) {
      return NextResponse.json(
        { error: 'Already spun today. Come back tomorrow!', canSpin: false },
        { status: 400 }
      );
    }
    
    // Calculate streak based on server-side state
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split('T')[0];
    
    let newStreak: number;
    if (lastSpinDate === yesterdayStr) {
      // Consecutive day
      newStreak = currentStreak + 1;
    } else if (lastSpinDate === '') {
      // First spin ever
      newStreak = 1;
    } else {
      // Streak broken
      newStreak = 1;
    }
    
    // Spin the wheel (cryptographic randomness)
    const prize = spinWheel();
    
    // Apply streak bonus: if 3+ days in a row, double points prizes
    let finalPrize = { ...prize };
    if (newStreak >= 3 && (prize.type === 'swiftPoints' || prize.type === 'jackpot')) {
      finalPrize = {
        ...prize,
        value: prize.value * 2,
        label: prize.label + ' (2x Streak!)',
      };
    }

    // Record spin server-side so the user can't spin again the same day
    spinStateMap.set(userId, { lastSpinDate: today, streak: newStreak });
    
    return NextResponse.json({
      prize: {
        id: finalPrize.id,
        type: finalPrize.type,
        value: finalPrize.value,
        label: finalPrize.label,
        rare: finalPrize.rare || false,
        jackpot: finalPrize.jackpot || false,
      },
      canSpin: false,
      streak: newStreak,
      spinDate: today,
    });
  } catch {
    return NextResponse.json(
      { error: 'Invalid request' },
      { status: 400 }
    );
  }
}
